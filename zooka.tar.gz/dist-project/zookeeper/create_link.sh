#!/usr/local/bin/bash

cd /tmp; ln -s /s/$HOSTNAME/a/tmp/pthakur-zookeeper/ pthakur-zookeeper; cd -
