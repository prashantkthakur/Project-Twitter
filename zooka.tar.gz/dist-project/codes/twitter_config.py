
#These information comes from Twitter API
#Create a Twitter Account and Get These Information from apps.twitter.com

consumer_key = 'lncre7iHgWzn1FALOwD739f3c'
consumer_secret = 'v8My6wEMvXRApUkWRHDNKdxbGd8kf84lulBldqLnsC1sIM4loK'
access_token = '919589727753216007-JiPL32eR0Cx6H4dmr8wlfMik8Sns23N'
access_secret = 'rMvaDpgSbgX5vCIyhQztEmJ3JZA65Kix2pK8GZmLyscbf'
